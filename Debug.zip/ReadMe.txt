Obfuscator.dll Was Not Made By Me Thanks To Whoever Made It.
(Update)Obfuscator.dll is still in development please consider not using it for now
